The bash-script will automatically start Logstash inside a Docker container.

This can be used to test the pipeline configuration in the pipeline-directory.
